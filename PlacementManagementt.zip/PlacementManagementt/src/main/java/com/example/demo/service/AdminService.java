
package com.example.demo.service;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entities.Admin;
import com.example.demo.repository.AdminRepository;

import jakarta.transaction.Transactional;
@Service
@Transactional
public class AdminService {
  @Autowired
  
  private AdminRepository repo;
  public List<Admin>listAll(){
	  return repo.findAll();
  }
  public void save (Admin admin) {
	  repo.save(admin);
	  }

	public Admin get(Integer id) {
		return repo.findById(id).get();
	}

	public void delete(Integer id) {
		repo.deleteById(id);
	}

  }
