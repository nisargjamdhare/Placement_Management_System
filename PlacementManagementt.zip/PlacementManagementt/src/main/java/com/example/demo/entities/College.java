package com.example.demo.entities;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class College {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int ID;
	private String CollegeAdmin;
	private String CollegeName;
	private String Location;

	public int getID() {
		return ID;
	}

	public void setID(int iD) {
		ID = iD;
	}

	public String getCollegeAdmin() {
		return CollegeAdmin;
	}

	public void setCollegeAdmin(String collegeAdmin) {
		CollegeAdmin = collegeAdmin;
	}

	public String getCollegeName() {
		return CollegeName;
	}

	public void setCollegeName(String collegeName) {
		CollegeName = collegeName;
	}

	public String getLocation() {
		return Location;
	}

	public void setLocation(String location) {
		Location = location;
	}
	
	@Override
	public String toString() {
		return "Product [ID=" + ID + ", CollegeAdmin=" + CollegeAdmin + ", CollegeName=" + CollegeName + ", Location="
				+ Location + "]";
	}

}
