package com.example.demo.entities;

import java.time.LocalDate;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Placement {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int ID;
	private String name;
	private String college;
	private LocalDate date;
	private String qualification;
	private int year;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getcollege() {
		return college;
	}

	public void setcollege(String college) {
		this.college = college;
	}
	public LocalDate getdate() {
		return date;
	}

	public void setdate(LocalDate date) {
		this.date = date;
	}

	public String getqualification() {
		return qualification;
	}

	public void setqualification(String qualification) {
		this.qualification = qualification;
	}
	public int  getyear() {
		return year;
	}

	public void setyear(int year) {
		this.year = year;
	}
	public int getID() {
		return ID;
	}

	@Override
	public String toString() {
		return "Placement [ID=" + ID + ", name=" + name + ", college=" + college + ", date=" + date + ", qualification="
				+ qualification + ", year=" + year + "]";
	}

	

}
