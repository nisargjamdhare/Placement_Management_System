package com.example.demo.entities;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Certificate {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long ID;
	private int Year;
	private String College;

	public int getYear() {
		return Year;
	}

	public void setYear(int Year) {
		this.Year = Year;
	}

	public String getCollege() {
		return College;
	}

	public void setPrice(String College) {
		this.College = College;
	}

	public long getID() {
		return ID;
	}

	@Override
	public String toString() {
		return "Certificate [ID=" + ID + ", year=" + Year + ", password=" + College + "]";
	}

}
