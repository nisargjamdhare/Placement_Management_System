package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entities.Certificate;
import com.example.demo.repository.CertificateRepository;

import jakarta.transaction.Transactional;

@Service
@Transactional
public class CertificateService {
	@Autowired
	private CertificateRepository repo;

	public List<Certificate> listAll() {
		return repo.findAll();
	}

	public void save(Certificate certificate) {
		repo.save(certificate);
	}

	public Certificate get(long id) {
		return repo.findById(id).get();
	}

	public void delete(long id) {
		repo.deleteById(id);
	}

}
